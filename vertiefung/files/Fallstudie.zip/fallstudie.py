#!/usr/bin/python3
import re
wörter = re.compile(r'\w+')
satzanfang = re.compile(r'[?!.] (\w+)')
groß = re.compile(r'[^?!.] ([A-ZÄÖÜ]\w+)')
dict = {}
große = {}
with open("europarl.txt", "r") as file:
    text = file.read()
    text = re.sub(r'\n', ' ', text)
    file.seek(0,0)

    for line in file:
        for word in re.findall(wörter, line):
            dict[word] = dict.get(word, 0) + 1


    for word in re.findall(satzanfang, text):
        klein = word.lower()

        if klein not in dict:
            große[word] = große.get(klein, 0) + 1

    for großeswort in re.findall(groß, text):
        große[großeswort] = große.get(großeswort, 0) + 1

for wort, frequenz in sorted(große.items(), key=lambda x: x[1]):
    if frequenz >= 10:
        print(wort,frequenz)
